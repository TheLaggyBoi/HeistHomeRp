TokoVoipConfig = {
	channels = {
		{name = "Call PD Radio", subscribers = {}},
		{name = "EMS Radio", subscribers = {}},
		{name = "PD/SO/EMS Shared Radio", subscribers = {}},
		{name = "SO Radio", subscribers = {}},
		{name = "PD/SO Shared Radio", subscribers = {}}
	}
};
